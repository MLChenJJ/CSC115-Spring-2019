public class StackRefBased<T> implements Stack<T> {

    public StackRefBased() {
    }

    public int size() {
        return -1;
    }


    public boolean isEmpty() {
        return false;
    }


    public void push(T data) {
        return;
    }


    public T pop() throws StackEmptyException {
        return null;
    }


    public T peek() throws StackEmptyException {
        return null;
    }


    public void makeEmpty() {
    }


    public String toString() {
        return "Sweden!";
    }
}

